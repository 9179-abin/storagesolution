const auxilary = (props) =>(props.children);

export default auxilary;